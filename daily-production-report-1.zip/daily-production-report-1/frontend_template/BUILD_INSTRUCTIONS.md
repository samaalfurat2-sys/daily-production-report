# Daily Production Report — Build Guide (APK + Windows EXE)

## Automated Build (GitHub Actions — Recommended)

The easiest way to get the APK and EXE is using the included GitHub Actions workflow:

1. Push this repository to GitHub
2. Go to **Actions** tab in your GitHub repo
3. Click **"Build APK & Windows EXE"** workflow
4. Click **"Run workflow"** to trigger a manual build
5. Once complete, download the artifacts:
   - **android-apk** — Contains `app-release.apk` (universal) and per-ABI APKs
   - **windows-exe** — Contains `DailyProductionReport-Windows.zip`

The workflow also runs automatically when you push changes to the `frontend_template/` folder.

When triggered via "Run workflow", it also creates a **GitHub Release** with all files attached for easy sharing.

---

## Manual Build — Prerequisites

1. **Flutter SDK** 3.4 or later — [Install Flutter](https://docs.flutter.dev/get-started/install)
2. **Android SDK** (API 34) — installed via Android Studio or `sdkmanager`
3. **Java 17** — required by AGP 8.x

Verify your setup:

```bash
flutter doctor
```

## Quick Build (Debug APK)

```bash
cd frontend_template
flutter pub get
flutter build apk --debug
```

The APK will be at: `build/app/outputs/flutter-apk/app-debug.apk`

## Production Build (Release APK)

### Step 1 — Set your server URL

The default server URL points to the Replit dev environment. For production, pass your deployed backend URL at build time:

```bash
flutter build apk --release --dart-define=BASE_URL=https://YOUR-DEPLOYED-BACKEND.replit.app
```

You can also change the server URL on the login screen at any time — no rebuild needed.

### Step 2 — (Optional) Configure release signing

For Play Store distribution, create a keystore and set these in `~/.gradle/gradle.properties`:

```properties
RELEASE_STORE_FILE=/path/to/release.keystore
RELEASE_STORE_PASSWORD=yourStorePassword
RELEASE_KEY_ALIAS=yourKeyAlias
RELEASE_KEY_PASSWORD=yourKeyPassword
```

Without these, the release build falls back to debug signing (fine for internal testing).

### Step 3 — Build

```bash
flutter build apk --release
```

The APK will be at: `build/app/outputs/flutter-apk/app-release.apk`

## Firebase Push Notifications (Optional)

The app works fully without Firebase. Push notifications are disabled by default.

To enable them:

1. Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Add an Android app with package name `com.dailyproduction.report`
3. Download `google-services.json` and replace the placeholder at `android/app/google-services.json`
4. Rebuild the app

## App Configuration

| Setting | How to change |
|---------|--------------|
| Server URL | Login screen field or `--dart-define=BASE_URL=...` at build |
| Language | In-app toggle (Arabic / English) on login and settings screens |
| Package name | `com.dailyproduction.report` in `android/app/build.gradle` |
| App name | `Daily Production Report` in `android/app/build.gradle` (`resValue`) |

## Demo Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | Admin1234 | Administrator |
| supervisor | Supervisor123 | Supervisor |
| operator | Operator123 | Operator |
| viewer | Viewer123 | Viewer |

## Troubleshooting

**"Flutter SDK not found"** — Run `flutter doctor` and ensure `local.properties` has the correct `flutter.sdk` path.

**"Firebase init failed"** — This is normal if you haven't configured Firebase. The app continues without push notifications.

**"Connection refused"** — Make sure your backend server is running and the URL on the login screen is correct. The app allows cleartext HTTP for local testing.

**Build fails on proguard** — The included `proguard-rules.pro` should handle Flutter. If you get errors, try building with `--no-shrink` first.

## Windows EXE (Local Build)

On a Windows machine with Flutter installed:

```bash
cd frontend_template
flutter config --enable-windows-desktop
flutter pub get
flutter build windows --release
```

The EXE will be at: `build\windows\x64\runner\Release\DailyProductionReport.exe`

Copy the entire `Release` folder to distribute — it contains the EXE and required DLLs.
