# Daily Production Report API

## Overview

A FastAPI backend for a bilingual Daily Production Report system. Originally designed with a Flutter frontend (Windows/Android native apps), the backend provides a full REST API for managing production shifts, warehouses, inventory, user authentication, and inter-warehouse stock transfers with approval workflow.

## Architecture

- **Backend**: FastAPI (Python 3.12) running on port 5000
- **Database**: PostgreSQL (Replit-managed, connected via `DATABASE_URL` env var)
- **Auth**: JWT-based authentication with roles (admin, supervisor, operator, viewer, warehouse_clerk, warehouse_supervisor)
- **ORM**: SQLAlchemy 2.0

## Project Structure

```
backend/
  app/
    main.py          - FastAPI app entry point, lifespan startup
    config.py        - Settings via pydantic-settings (reads .env)
    database.py      - SQLAlchemy engine/session setup
    models.py        - SQLAlchemy models (incl. StockTransfer, StockTransferLine)
    schemas.py       - Pydantic schemas (incl. transfer schemas)
    deps.py          - FastAPI dependency injection (auth, roles)
    security.py      - JWT encode/decode
    calculations.py  - Business logic calculations
    inventory.py     - Inventory management logic
    onedrive_client.py - Microsoft Graph API integration
    production.py    - BOM-based consumption calculation & posting
    pdf_reports.py   - A4 PDF report generation (bilingual AR/EN, reportlab)
    ws_manager.py    - WebSocket connection manager for real-time sync
    routers/
      auth.py        - Authentication endpoints
      users.py       - User management
      shifts.py      - Shift report CRUD + production lines + consumption preview
      warehouses.py  - Warehouse/inventory endpoints
      transfers.py   - Stock transfer endpoints (create, list, accept/reject)
      products.py    - Product catalog & BOM listing
      reports.py     - PDF report download endpoints
      notifications.py - Push notification list/read/count endpoints
      onedrive_sync.py - OneDrive integration endpoints
    scripts/
      create_admin.py  - Seeds roles, units, warehouses, products & BOM on startup
      seed_demo.py     - Seeds demo users
  .env               - Local environment config
  requirements.txt   - Python dependencies
frontend_template/   - Flutter app source (for native Windows/Android builds)
```

## Warehouses

| Code | Type | Name (EN) |
|------|------|-----------|
| WH1 | RAW | Raw Materials Warehouse |
| WH2 | PRODUCTION | Production Hall Warehouse |
| WH2.1 | PRODUCTION_MISSING | Missing Raw Materials from Production Hall |
| WH3 | FINISHED | Final Product Warehouse |
| WH4 | FUEL | Fuel Inventory Warehouse |
| WH5 | GENERATOR | Power Generator Warehouse |

## Stock Transfer Workflow

1. Warehouse keeper creates a transfer (POST /transfers) with source/destination warehouse and item lines
2. Transfer starts in PENDING status
3. Receiving warehouse keeper responds (POST /transfers/{id}/respond) with ACCEPTED or REJECTED
4. On ACCEPTED: inventory transactions are created (ISSUE from source, RECEIVE at destination)
5. On REJECTED: no inventory movement; response_note explains the non-compliance

## Production & BOM Consumption

### Products (seeded on startup)

| Code | Description | Bottles/Carton |
|------|-------------|----------------|
| 750x20 | Water 750ml × 20 bottles | 20 |
| 750x12 | Water 750ml × 12 bottles | 12 |
| 1500x12 | Water 1500ml × 12 bottles | 12 |
| 330x30 | Water 330ml × 30 bottles | 30 |

### Shift Production Workflow

1. Operator adds production lines to a shift (PUT /shifts/{id}/production) with product codes and cartons produced
2. Consumption preview available (GET /shifts/{id}/consumption) showing raw material requirements vs WH2 stock
3. On shift approval:
   - Raw materials ISSUEd from WH2 (up to available stock)
   - Shortfalls auto-posted as RECEIVE to WH2.1 (missing materials warehouse)
   - Finished products RECEIVEd into WH3

## PDF Reports (A4)

All reports are bilingual (Arabic/English) and served as downloadable A4 PDFs.

| Endpoint | Description |
|----------|-------------|
| `GET /reports/warehouse/{code}` | Individual warehouse inventory + transactions report |
| `GET /reports/warehouses/all` | All warehouses combined (one page per warehouse) |
| `GET /reports/transfers` | Inter-warehouse transfer status report |
| `GET /reports/shift/{shift_id}` | Shift production report (all units + BOM consumption) |

Query params: `date_from`, `date_to`, `warehouse_code`, `status` (where applicable).

## Push Notifications

Targeted bilingual (AR/EN) notifications are sent to relevant users for each action:

| Action | Recipients |
|--------|-----------|
| Transfer created | All warehouse_clerk + warehouse_supervisor (except issuer) |
| Transfer accepted/rejected | The original issuer |
| Shift submitted | All supervisor + warehouse_supervisor (except submitter) |
| Shift approved | The shift creator and submitter |
| Shift locked | The creator, submitter, and approver |
| Inventory transaction | All warehouse_clerk + warehouse_supervisor (except actor) |

### Notification API

| Endpoint | Description |
|----------|-------------|
| `GET /notifications` | List user's notifications (supports `unread_only` filter) |
| `GET /notifications/count` | Get unread/total count |
| `POST /notifications/{id}/read` | Mark a notification as read |
| `POST /notifications/read-all` | Mark all notifications as read |

Notifications are also pushed in real-time via WebSocket as `{"event": "notification", ...}` messages to connected users.

## Real-Time WebSocket Sync

Clients connect to `ws://host:5000/ws?token=JWT_TOKEN` to receive live updates. The WebSocket requires a valid JWT token (same as REST API auth).

### Events Broadcast

| Event | Entity | Trigger |
|-------|--------|---------|
| `created` | `shift` | New shift created |
| `updated` | `shift` | Shift unit data updated (blow, filling, label, shrink, diesel, production) |
| `submitted` | `shift` | Shift submitted for approval |
| `approved` | `shift` | Shift approved |
| `locked` | `shift` | Shift locked |
| `created` | `transfer` | New stock transfer created |
| `responded` | `transfer` | Transfer accepted/rejected |
| `created` | `inventory_transaction` | Manual inventory transaction |
| `updated` | `inventory` | Inventory changed (shift approval, transfer, manual txn) |
| `created` | `user` | New user created |

### Client Usage
- Connect: `ws://host/ws?token=<jwt>`
- Ping/pong: Send `"ping"`, receive `{"event":"pong"}`
- Events arrive as JSON: `{"event": "...", "entity": "...", "data": {...}, "timestamp": "..."}`

## Key Configuration

- `DATABASE_URL` - PostgreSQL URL (set automatically by Replit environment)
- `JWT_SECRET` - Secret key for JWT signing
- `CORS_ORIGINS` - Allowed CORS origins (default: `*`)
- `SEED_DEMO` - Auto-seed demo accounts on startup
- `ONEDRIVE_*` - Optional Microsoft OneDrive integration

## Demo Accounts

After startup, these accounts are available:
- `admin` / `Admin1234`
- `supervisor` / `Supervisor123`
- `operator` / `Operator123`
- `viewer` / `Viewer123`

## API Docs

Available at `/docs` (Swagger UI) or `/redoc` when the server is running.

## Workflow

- **Start application**: `cd backend && uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload`
