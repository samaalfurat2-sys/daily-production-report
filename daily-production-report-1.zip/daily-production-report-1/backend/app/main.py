from contextlib import asynccontextmanager
import asyncio
import uuid as _uuid
import logging

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from jose import jwt, JWTError

from app.config import settings
from app.database import Base, engine, SessionLocal
from app.routers.auth import router as auth_router
from app.routers.users import router as users_router
from app.routers.shifts import router as shifts_router
from app.routers.warehouses import router as warehouses_router
from app.routers.onedrive_sync import router as onedrive_router
from app.routers.transfers import router as transfers_router
from app.routers.products import router as products_router
from app.routers.reports import router as reports_router
from app.routers.notifications import router as notifications_router
from app.scripts.create_admin import ensure_roles_and_units, ensure_warehouses_and_items, ensure_products_and_bom
from app.ws_manager import manager
from app import models  # noqa: F401 – ensure models are imported so Base sees them

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Run startup logic once, then yield for requests."""
    Base.metadata.create_all(bind=engine)
    manager.set_loop(asyncio.get_running_loop())
    db = SessionLocal()
    try:
        ensure_roles_and_units(db)
        ensure_warehouses_and_items(db)
        ensure_products_and_bom(db)
    finally:
        db.close()
    yield


app = FastAPI(
    title="Daily Production Report API",
    version="2.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {
        "app": "Daily Production Report API",
        "version": "2.3.0",
        "status": "online",
        "docs": "/docs",
        "health": "/health",
        "endpoints": {
            "auth": "/auth/login",
            "shifts": "/shifts",
            "warehouses": "/warehouses",
            "inventory": "/inventory/stock",
            "transfers": "/transfers",
            "products": "/products",
            "notifications": "/notifications",
            "reports": "/reports/warehouses",
            "websocket": "/ws?token=JWT",
        },
    }


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)


@app.get("/health")
def health():
    return {
        "ok": True,
        "app": "daily-production-report-api",
        "version": "2.3.0",
        "ws_clients": manager.active_count,
    }


@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = Query(default=""),
):
    if not token:
        await websocket.close(code=4001, reason="Missing token")
        return
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        user_id = payload.get("sub", "unknown")
    except JWTError:
        await websocket.close(code=4003, reason="Invalid token")
        return

    client_id = str(_uuid.uuid4())
    await manager.connect(websocket, client_id, user_id)
    try:
        while True:
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text('{"event":"pong"}')
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(client_id)


app.include_router(auth_router)
app.include_router(users_router)
app.include_router(shifts_router)
app.include_router(warehouses_router)
app.include_router(onedrive_router)
app.include_router(transfers_router)
app.include_router(products_router)
app.include_router(reports_router)
app.include_router(notifications_router)
