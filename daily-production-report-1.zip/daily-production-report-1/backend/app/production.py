from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy import func, case

from app import models
from app.inventory import create_inventory_txn


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _stock_on_hand_wh2(db: Session, item_id) -> float:
    wh2 = db.query(models.Warehouse).filter(models.Warehouse.code == "WH2").first()
    if not wh2:
        return 0.0
    result = (
        db.query(
            func.coalesce(
                func.sum(
                    case(
                        (
                            models.InventoryTransaction.txn_type.in_(["RECEIVE", "ADJUST"]),
                            models.InventoryTransaction.qty,
                        ),
                        else_=-models.InventoryTransaction.qty,
                    )
                ),
                0,
            )
        )
        .filter(
            models.InventoryTransaction.warehouse_id == wh2.id,
            models.InventoryTransaction.item_id == item_id,
        )
        .scalar()
    )
    return float(result or 0)


def calculate_shift_consumption(
    db: Session, shift: models.ShiftRecord
) -> Tuple[Dict[str, float], List[models.ShiftProductionLine]]:
    required: Dict[str, float] = defaultdict(float)

    for pl in shift.production_lines:
        cartons = float(pl.cartons_produced or 0)
        if cartons <= 0:
            continue
        product = pl.product
        for bom_line in product.bom_lines:
            required[bom_line.item.code] += float(bom_line.qty_per_carton) * cartons

    return dict(required), shift.production_lines


def post_production_inventory(
    db: Session, shift: models.ShiftRecord, user_id
) -> Dict[str, Dict]:
    now = _utcnow()
    report_date = shift.report_date

    wh2 = db.query(models.Warehouse).filter(models.Warehouse.code == "WH2").first()
    wh2_1 = db.query(models.Warehouse).filter(models.Warehouse.code == "WH2.1").first()
    wh3 = db.query(models.Warehouse).filter(models.Warehouse.code == "WH3").first()

    if not wh2 or not wh3:
        return {"error": "WH2 or WH3 warehouse not found"}

    required, production_lines = calculate_shift_consumption(db, shift)

    consumption_results = {}

    for item_code, total_needed in required.items():
        item = db.query(models.InventoryItem).filter(
            models.InventoryItem.code == item_code
        ).first()
        if not item:
            continue

        on_hand = _stock_on_hand_wh2(db, item.id)
        consumed = min(on_hand, total_needed)
        missing = total_needed - consumed

        if consumed > 0:
            create_inventory_txn(
                db,
                warehouse=wh2,
                item=item,
                txn_type="ISSUE",
                qty=consumed,
                txn_date=report_date,
                created_by=user_id,
                reference_type="SHIFT_PRODUCTION",
                reference_id=str(shift.id),
                note=f"Production consumption shift {shift.shift_code} date {report_date}",
            )

        if missing > 0 and wh2_1:
            create_inventory_txn(
                db,
                warehouse=wh2_1,
                item=item,
                txn_type="RECEIVE",
                qty=missing,
                txn_date=report_date,
                created_by=user_id,
                reference_type="SHIFT_PRODUCTION_MISSING",
                reference_id=str(shift.id),
                note=f"Missing raw material from shift {shift.shift_code} date {report_date}",
            )

        consumption_results[item_code] = {
            "total_required": total_needed,
            "wh2_on_hand": on_hand,
            "consumed_from_wh2": consumed,
            "missing_to_wh2_1": missing,
        }

    finished_cartons = defaultdict(float)
    for pl in production_lines:
        cartons = float(pl.cartons_produced or 0)
        if cartons <= 0:
            continue
        product = pl.product
        fp_code = f"FP_{product.code}"
        fp_item = db.query(models.InventoryItem).filter(
            models.InventoryItem.code == fp_code
        ).first()
        if fp_item and wh3:
            create_inventory_txn(
                db,
                warehouse=wh3,
                item=fp_item,
                txn_type="RECEIVE",
                qty=cartons,
                txn_date=report_date,
                created_by=user_id,
                reference_type="SHIFT_PRODUCTION",
                reference_id=str(shift.id),
                note=f"Finished product from shift {shift.shift_code} date {report_date}",
            )
            finished_cartons[fp_code] += cartons

    return {
        "consumption": consumption_results,
        "finished_cartons": dict(finished_cartons),
    }
