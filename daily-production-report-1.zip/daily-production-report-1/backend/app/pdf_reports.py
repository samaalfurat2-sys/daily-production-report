from __future__ import annotations

import io
from datetime import date, datetime
from typing import List, Optional

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak,
)

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    HAS_BIDI = True
except ImportError:
    HAS_BIDI = False

FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_PATH_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

try:
    pdfmetrics.registerFont(TTFont("DejaVu", FONT_PATH))
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", FONT_PATH_BOLD))
    FONT_NAME = "DejaVu"
    FONT_BOLD = "DejaVu-Bold"
except Exception:
    FONT_NAME = "Helvetica"
    FONT_BOLD = "Helvetica-Bold"

PAGE_W, PAGE_H = A4


def _ar(text: str) -> str:
    if not text or not HAS_BIDI:
        return text
    try:
        reshaped = arabic_reshaper.reshape(text)
        return get_display(reshaped)
    except Exception:
        return text


def _fmt(val, decimals=2) -> str:
    if val is None:
        return "-"
    try:
        f = float(val)
        if f == int(f) and decimals <= 2:
            return str(int(f))
        return f"{f:,.{decimals}f}"
    except (ValueError, TypeError):
        return str(val)


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("TitleAr", fontName=FONT_BOLD, fontSize=16, alignment=TA_CENTER, leading=20, spaceAfter=4))
    ss.add(ParagraphStyle("TitleEn", fontName=FONT_BOLD, fontSize=14, alignment=TA_CENTER, leading=18, spaceAfter=8))
    ss.add(ParagraphStyle("SubHead", fontName=FONT_BOLD, fontSize=11, alignment=TA_LEFT, leading=14, spaceAfter=4, spaceBefore=10))
    ss.add(ParagraphStyle("CellText", fontName=FONT_NAME, fontSize=8, alignment=TA_LEFT, leading=10))
    ss.add(ParagraphStyle("CellTextR", fontName=FONT_NAME, fontSize=8, alignment=TA_RIGHT, leading=10))
    ss.add(ParagraphStyle("CellBold", fontName=FONT_BOLD, fontSize=8, alignment=TA_LEFT, leading=10))
    ss.add(ParagraphStyle("FooterText", fontName=FONT_NAME, fontSize=7, alignment=TA_CENTER, textColor=colors.grey))
    ss.add(ParagraphStyle("MetaText", fontName=FONT_NAME, fontSize=9, alignment=TA_LEFT, leading=12))
    return ss


HEADER_BG = colors.HexColor("#2C3E50")
HEADER_FG = colors.white
ALT_ROW = colors.HexColor("#F7F9FC")
GRID_COLOR = colors.HexColor("#BDC3C7")


def _table_style(n_rows, col_count):
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
        ("TEXTCOLOR", (0, 0), (-1, 0), HEADER_FG),
        ("FONTNAME", (0, 0), (-1, 0), FONT_BOLD),
        ("FONTSIZE", (0, 0), (-1, 0), 8),
        ("FONTNAME", (0, 1), (-1, -1), FONT_NAME),
        ("FONTSIZE", (0, 1), (-1, -1), 8),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, GRID_COLOR),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]
    for i in range(1, n_rows):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), ALT_ROW))
    return TableStyle(style)


def _footer(canvas, doc, title_text: str = ""):
    canvas.saveState()
    canvas.setFont(FONT_NAME, 7)
    canvas.setFillColor(colors.grey)
    canvas.drawString(15 * mm, 10 * mm, f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    if title_text:
        canvas.drawCentredString(PAGE_W / 2, 10 * mm, title_text)
    canvas.drawRightString(PAGE_W - 15 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def generate_warehouse_inventory_report(
    warehouse_code: str,
    warehouse_name_ar: str,
    warehouse_name_en: str,
    transactions: list,
    stock_rows: list,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=15 * mm, bottomMargin=20 * mm,
    )
    ss = _styles()
    elements = []

    title_ar = _ar(f"تقرير مستودع {warehouse_name_ar}")
    elements.append(Paragraph(title_ar, ss["TitleAr"]))
    elements.append(Paragraph(f"Warehouse Report: {warehouse_name_en} ({warehouse_code})", ss["TitleEn"]))

    period = ""
    if date_from and date_to:
        period = f"Period: {date_from} to {date_to}"
    elif date_from:
        period = f"From: {date_from}"
    elif date_to:
        period = f"Up to: {date_to}"
    if period:
        elements.append(Paragraph(period, ss["MetaText"]))
    elements.append(Spacer(1, 6 * mm))

    elements.append(Paragraph(_ar("المخزون الحالي") + " / Stock on Hand", ss["SubHead"]))
    if stock_rows:
        hdr = ["#", "Item Code", _ar("اسم الصنف"), "UOM", "Qty on Hand"]
        data = [hdr]
        for i, sr in enumerate(stock_rows, 1):
            data.append([
                str(i),
                sr["item_code"],
                _ar(sr["item_name_ar"]),
                sr["uom"],
                _fmt(sr["qty_on_hand"]),
            ])
        col_w = [8 * mm, 35 * mm, 55 * mm, 20 * mm, 30 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        t.setStyle(_table_style(len(data), len(hdr)))
        elements.append(t)
    else:
        elements.append(Paragraph("No stock on hand.", ss["MetaText"]))

    elements.append(Spacer(1, 8 * mm))
    elements.append(Paragraph(_ar("حركات المستودع") + " / Inventory Transactions", ss["SubHead"]))

    if transactions:
        hdr = ["#", "Date", "Type", "Item Code", _ar("اسم الصنف"), "Qty", "Reference", "Note"]
        data = [hdr]
        for i, tx in enumerate(transactions, 1):
            data.append([
                str(i),
                str(tx["txn_date"]),
                tx["txn_type"],
                tx["item_code"],
                _ar(tx["item_name_ar"]),
                _fmt(tx["qty"]),
                tx.get("reference_type", "") or "",
                (tx.get("note", "") or "")[:40],
            ])
        col_w = [7 * mm, 22 * mm, 16 * mm, 30 * mm, 40 * mm, 18 * mm, 22 * mm, 30 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        t.setStyle(_table_style(len(data), len(hdr)))
        elements.append(t)
    else:
        elements.append(Paragraph("No transactions found.", ss["MetaText"]))

    footer_text = f"{warehouse_code} - {warehouse_name_en}"
    doc.build(elements, onFirstPage=lambda c, d: _footer(c, d, footer_text),
              onLaterPages=lambda c, d: _footer(c, d, footer_text))
    return buf.getvalue()


def generate_transfers_report(
    transfers: list,
    warehouse_code: Optional[str] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=15 * mm, bottomMargin=20 * mm,
    )
    ss = _styles()
    elements = []

    title_ar = _ar("تقرير التحويلات بين المستودعات")
    elements.append(Paragraph(title_ar, ss["TitleAr"]))
    subtitle = "Inter-Warehouse Transfer Report"
    if warehouse_code:
        subtitle += f" — {warehouse_code}"
    elements.append(Paragraph(subtitle, ss["TitleEn"]))

    period = ""
    if date_from and date_to:
        period = f"Period: {date_from} to {date_to}"
    elif date_from:
        period = f"From: {date_from}"
    if period:
        elements.append(Paragraph(period, ss["MetaText"]))
    elements.append(Spacer(1, 6 * mm))

    if transfers:
        hdr = ["#", "Transfer #", "From", "To", "Status", "Issued By", "Date", "Items"]
        data = [hdr]
        for i, tr in enumerate(transfers, 1):
            items_str = "; ".join(
                f"{ln['item_code']} x{_fmt(ln['qty'])}"
                for ln in tr.get("lines", [])
            )
            data.append([
                str(i),
                tr["transfer_number"],
                tr["from_warehouse_code"],
                tr["to_warehouse_code"],
                tr["status"],
                tr.get("issued_by_username", ""),
                str(tr.get("issued_at", ""))[:10],
                items_str[:50],
            ])
        col_w = [7 * mm, 25 * mm, 18 * mm, 18 * mm, 20 * mm, 25 * mm, 22 * mm, 50 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        t.setStyle(_table_style(len(data), len(hdr)))
        elements.append(t)

        elements.append(Spacer(1, 6 * mm))
        summary = {}
        for tr in transfers:
            s = tr["status"]
            summary[s] = summary.get(s, 0) + 1
        summary_text = " | ".join(f"{k}: {v}" for k, v in sorted(summary.items()))
        elements.append(Paragraph(f"Summary: {summary_text} | Total: {len(transfers)}", ss["MetaText"]))
    else:
        elements.append(Paragraph("No transfers found.", ss["MetaText"]))

    doc.build(elements, onFirstPage=lambda c, d: _footer(c, d, "Transfer Report"),
              onLaterPages=lambda c, d: _footer(c, d, "Transfer Report"))
    return buf.getvalue()


def generate_shift_production_report(
    shift_data: dict,
    production_lines: list,
    consumption: list,
    finished_cartons: dict,
) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=15 * mm, bottomMargin=20 * mm,
    )
    ss = _styles()
    elements = []

    report_date = shift_data.get("report_date", "")
    shift_code = shift_data.get("shift_code", "")
    status = shift_data.get("status", "")

    title_ar = _ar(f"تقرير الإنتاج - وردية {shift_code}")
    elements.append(Paragraph(title_ar, ss["TitleAr"]))
    elements.append(Paragraph(f"Production Report — Shift {shift_code}", ss["TitleEn"]))
    elements.append(Spacer(1, 3 * mm))

    meta_data = [
        [_ar("التاريخ") + " / Date", str(report_date), _ar("الوردية") + " / Shift", shift_code],
        [_ar("الحالة") + " / Status", status, "", ""],
    ]
    meta_t = Table(meta_data, colWidths=[40 * mm, 50 * mm, 40 * mm, 50 * mm])
    meta_t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), FONT_NAME),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), FONT_BOLD),
        ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
        ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elements.append(meta_t)
    elements.append(Spacer(1, 6 * mm))

    blow = shift_data.get("blow")
    if blow:
        elements.append(Paragraph(_ar("وحدة النفخ") + " / Blow Molding Unit", ss["SubHead"]))
        blow_data = [
            [_ar("بداية الكراتين"), _fmt(blow.get("prev_cartons")),
             _ar("كراتين مستلمة"), _fmt(blow.get("received_cartons"))],
            [_ar("كراتين منتجة"), _fmt(blow.get("product_cartons")),
             _ar("نهاية الكراتين"), _fmt(blow.get("next_cartons"))],
            [_ar("هالك بريفورم"), _fmt(blow.get("waste_preforms_pcs")),
             _ar("هالك قوارير"), _fmt(blow.get("waste_bottles_pcs"))],
            [_ar("عداد"), _fmt(blow.get("counter_value")),
             _ar("هالك سكراب"), _fmt(blow.get("waste_scrap_pcs"))],
        ]
        bt = Table(blow_data, colWidths=[40 * mm, 40 * mm, 40 * mm, 40 * mm])
        bt.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME), ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), FONT_BOLD), ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
            ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        elements.append(bt)
        elements.append(Spacer(1, 3 * mm))

    filling = shift_data.get("filling")
    if filling:
        elements.append(Paragraph(_ar("وحدة التعبئة") + " / Filling Unit", ss["SubHead"]))
        fill_data = [
            [_ar("بداية الكراتين"), _fmt(filling.get("prev_cartons")),
             _ar("كراتين مستلمة"), _fmt(filling.get("received_cartons"))],
            [_ar("نهاية الكراتين"), _fmt(filling.get("next_cartons")),
             _ar("هالك أغطية"), _fmt(filling.get("waste_caps_pcs"))],
            [_ar("عداد"), _fmt(filling.get("counter_value")),
             _ar("هالك قوارير"), _fmt(filling.get("waste_bottles_pcs"))],
        ]
        ft = Table(fill_data, colWidths=[40 * mm, 40 * mm, 40 * mm, 40 * mm])
        ft.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME), ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), FONT_BOLD), ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
            ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        elements.append(ft)
        elements.append(Spacer(1, 3 * mm))

    label = shift_data.get("label")
    if label:
        elements.append(Paragraph(_ar("وحدة اللصق") + " / Labeling Unit", ss["SubHead"]))
        lbl_data = [
            [_ar("بداية الرولات"), _fmt(label.get("prev_rolls")),
             _ar("رولات مستلمة"), _fmt(label.get("received_rolls"))],
            [_ar("نهاية الرولات"), _fmt(label.get("next_rolls")),
             _ar("هالك غرام"), _fmt(label.get("waste_grams"))],
        ]
        lt = Table(lbl_data, colWidths=[40 * mm, 40 * mm, 40 * mm, 40 * mm])
        lt.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME), ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), FONT_BOLD), ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
            ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        elements.append(lt)
        elements.append(Spacer(1, 3 * mm))

    shrink = shift_data.get("shrink")
    if shrink:
        elements.append(Paragraph(_ar("وحدة التغليف") + " / Shrink Wrapping Unit", ss["SubHead"]))
        sh_data = [
            [_ar("بداية الرولات"), _fmt(shrink.get("prev_rolls")),
             _ar("رولات مستلمة"), _fmt(shrink.get("received_rolls"))],
            [_ar("نهاية الرولات"), _fmt(shrink.get("next_rolls")),
             _ar("هالك كغ"), _fmt(shrink.get("waste_kg"))],
            [_ar("عداد الشاشة"), _fmt(shrink.get("screen_counter")), "", ""],
        ]
        st = Table(sh_data, colWidths=[40 * mm, 40 * mm, 40 * mm, 40 * mm])
        st.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME), ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), FONT_BOLD), ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
            ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        elements.append(st)
        elements.append(Spacer(1, 3 * mm))

    diesel = shift_data.get("diesel")
    if diesel:
        elements.append(Paragraph(_ar("الديزل والمولدات") + " / Diesel & Generators", ss["SubHead"]))
        ds_data = [
            [_ar("مولد 1 - القراءة"), _fmt(diesel.get("generator1_total_reading")),
             _ar("مولد 1 - الاستهلاك"), _fmt(diesel.get("generator1_consumed"))],
            [_ar("مولد 2 - القراءة"), _fmt(diesel.get("generator2_total_reading")),
             _ar("مولد 2 - الاستهلاك"), _fmt(diesel.get("generator2_consumed"))],
            [_ar("خزان رئيسي مستلم"), _fmt(diesel.get("main_tank_received")), "", ""],
        ]
        dt = Table(ds_data, colWidths=[40 * mm, 40 * mm, 40 * mm, 40 * mm])
        dt.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME), ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), FONT_BOLD), ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
            ("GRID", (0, 0), (-1, -1), 0.3, GRID_COLOR),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        elements.append(dt)
        elements.append(Spacer(1, 3 * mm))

    if production_lines:
        elements.append(Paragraph(_ar("خطوط الإنتاج") + " / Production Lines", ss["SubHead"]))
        hdr = ["#", "Product Code", _ar("المنتج"), "Bottles/Carton", "Volume (ml)", "Cartons Produced"]
        data = [hdr]
        total_cartons = 0
        for i, pl in enumerate(production_lines, 1):
            cartons = float(pl.get("cartons_produced", 0))
            total_cartons += cartons
            data.append([
                str(i),
                pl.get("product_code", ""),
                _ar(pl.get("product_name_ar", "")),
                _fmt(pl.get("bottles_per_carton")),
                _fmt(pl.get("bottle_volume_ml")),
                _fmt(cartons),
            ])
        data.append(["", "", "", "", _ar("المجموع") + " / Total", _fmt(total_cartons)])
        col_w = [7 * mm, 28 * mm, 42 * mm, 25 * mm, 25 * mm, 30 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        style_list = list(_table_style(len(data), len(hdr)).getCommands())
        style_list.append(("FONTNAME", (0, -1), (-1, -1), FONT_BOLD))
        style_list.append(("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#ECF0F1")))
        t.setStyle(TableStyle(style_list))
        elements.append(t)
        elements.append(Spacer(1, 4 * mm))

    if consumption:
        elements.append(Paragraph(_ar("استهلاك المواد الخام") + " / Raw Material Consumption", ss["SubHead"]))
        hdr = ["#", "Item Code", _ar("الصنف"), "UOM", "Required", "WH2 Stock", "Consumed", "Missing (WH2.1)"]
        data = [hdr]
        for i, c in enumerate(consumption, 1):
            data.append([
                str(i),
                c.get("item_code", ""),
                _ar(c.get("item_name_ar", "")),
                c.get("uom", ""),
                _fmt(c.get("total_required")),
                _fmt(c.get("wh2_on_hand")),
                _fmt(c.get("consumed_from_wh2")),
                _fmt(c.get("missing_to_wh2_1")),
            ])
        col_w = [7 * mm, 28 * mm, 35 * mm, 15 * mm, 22 * mm, 22 * mm, 22 * mm, 28 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        ts = _table_style(len(data), len(hdr))
        t.setStyle(ts)
        elements.append(t)
        elements.append(Spacer(1, 4 * mm))

    if finished_cartons:
        elements.append(Paragraph(_ar("المنتج النهائي") + " / Finished Products to WH3", ss["SubHead"]))
        hdr = ["#", "Product Code", "Cartons"]
        data = [hdr]
        for i, (fp_code, qty) in enumerate(finished_cartons.items(), 1):
            data.append([str(i), fp_code, _fmt(qty)])
        col_w = [10 * mm, 60 * mm, 40 * mm]
        t = Table(data, colWidths=col_w, repeatRows=1)
        t.setStyle(_table_style(len(data), len(hdr)))
        elements.append(t)

    footer_text = f"Shift {shift_code} — {report_date}"
    doc.build(elements, onFirstPage=lambda c, d: _footer(c, d, footer_text),
              onLaterPages=lambda c, d: _footer(c, d, footer_text))
    return buf.getvalue()
