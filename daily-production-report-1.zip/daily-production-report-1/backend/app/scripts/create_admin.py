from app.database import SessionLocal, Base, engine
from app import models
from app.security import hash_password


def ensure_roles_and_units(db):
    role_names = ["admin", "supervisor", "operator", "viewer", "warehouse_clerk", "warehouse_supervisor"]
    for name in role_names:
        if not db.query(models.Role).filter(models.Role.name == name).first():
            db.add(models.Role(name=name))

    units = [
        ("blow", "النفخ", "Blow"),
        ("filling", "التعبئة", "Filling"),
        ("label", "ليبل", "Label"),
        ("shrink", "شرنك", "Shrink"),
        ("diesel", "سولار", "Diesel"),
    ]
    for code, ar, en in units:
        if not db.query(models.Unit).filter(models.Unit.code == code).first():
            db.add(models.Unit(code=code, name_ar=ar, name_en=en))
    db.commit()


def ensure_warehouses_and_items(db):
    warehouses = [
        ("WH1", "RAW", "مخزن المواد الخام", "Raw Materials Warehouse"),
        ("WH2", "PRODUCTION", "مخزن صالة الإنتاج", "Production Hall Warehouse"),
        ("WH2.1", "PRODUCTION_MISSING", "نواقص المواد الخام من صالة الإنتاج", "Missing Raw Materials from Production Hall"),
        ("WH3", "FINISHED", "مخزن المنتج النهائي", "Final Product Warehouse"),
        ("WH4", "FUEL", "مخزن الوقود", "Fuel Inventory Warehouse"),
        ("WH5", "GENERATOR", "مخزن المولدات", "Power Generator Warehouse"),
        ("RM", "RAW", "مخزن المواد الخام (قديم)", "Raw Materials Warehouse (legacy)"),
        ("FG", "FINISHED", "مخزن المنتج النهائي (قديم)", "Finished Goods Warehouse (legacy)"),
    ]
    for code, typ, ar, en in warehouses:
        if not db.query(models.Warehouse).filter(models.Warehouse.code == code).first():
            db.add(models.Warehouse(code=code, type=typ, name_ar=ar, name_en=en))

    items = [
        ("RM_PREFORM_CARTON", "RAW_MATERIAL", "بريفورم كرتون", "Preform Carton", "carton"),
        ("RM_CAPS_CARTON", "RAW_MATERIAL", "أغطية كرتون", "Caps Carton", "carton"),
        ("RM_LABEL_ROLL", "RAW_MATERIAL", "ليبل روله", "Label Roll", "roll"),
        ("RM_SHRINK_ROLL", "RAW_MATERIAL", "شرنك روله", "Shrink Roll", "roll"),
        ("RM_DIESEL_LITER", "RAW_MATERIAL", "سولار", "Diesel", "liter"),
        ("FG_TOTAL_CARTON", "FINISHED_GOOD", "منتج نهائي كرتون", "Finished Goods Carton", "carton"),
        ("FUEL_DIESEL", "FUEL", "وقود ديزل", "Diesel Fuel", "liter"),
        ("GEN_PART", "GENERATOR", "قطع غيار مولدات", "Generator Parts", "piece"),
        ("PREFORM_20_5G", "RAW_MATERIAL", "بريفورم 20.5 جرام", "Preform 20.5g (750ml)", "piece"),
        ("PREFORM_30G", "RAW_MATERIAL", "بريفورم 30 جرام", "Preform 30g (1500ml)", "piece"),
        ("PREFORM_11_7G", "RAW_MATERIAL", "بريفورم 11.7 جرام", "Preform 11.7g (330ml)", "piece"),
        ("CAPS_1_7G", "RAW_MATERIAL", "أغطية 1.7 جرام", "Caps 1.7g", "piece"),
        ("LABEL_750ML", "RAW_MATERIAL", "ليبل 750 مل", "Label 750ml", "piece"),
        ("LABEL_1500ML", "RAW_MATERIAL", "ليبل 1500 مل", "Label 1500ml", "piece"),
        ("LABEL_330ML", "RAW_MATERIAL", "ليبل 330 مل", "Label 330ml", "piece"),
        ("SHRINK_560M", "RAW_MATERIAL", "شرنك 560 متر", "Shrink wrap 560m", "gram"),
        ("SHRINK_470M", "RAW_MATERIAL", "شرنك 470 متر", "Shrink wrap 470m", "gram"),
        ("FP_750x20", "FINISHED_GOOD", "منتج نهائي 750مل×20", "Finished Product 750ml×20", "carton"),
        ("FP_1500x12", "FINISHED_GOOD", "منتج نهائي 1500مل×12", "Finished Product 1500ml×12", "carton"),
        ("FP_330x30", "FINISHED_GOOD", "منتج نهائي 330مل×30", "Finished Product 330ml×30", "carton"),
        ("FP_750x12", "FINISHED_GOOD", "منتج نهائي 750مل×12", "Finished Product 750ml×12", "carton"),
    ]
    for code, typ, ar, en, uom in items:
        if not db.query(models.InventoryItem).filter(models.InventoryItem.code == code).first():
            db.add(models.InventoryItem(code=code, item_type=typ, name_ar=ar, name_en=en, uom=uom))
    db.commit()


def _get_item(db, code):
    return db.query(models.InventoryItem).filter(models.InventoryItem.code == code).first()


def ensure_products_and_bom(db):
    products_data = [
        {
            "code": "750x20",
            "name_ar": "مياه 750 مل × 20 زجاجة",
            "name_en": "Water 750ml × 20 bottles",
            "bottle_volume_ml": 750,
            "bottles_per_carton": 20,
            "bom": [
                ("PREFORM_20_5G", 20),
                ("CAPS_1_7G", 20),
                ("LABEL_750ML", 20),
                ("SHRINK_560M", 0.55),
            ],
        },
        {
            "code": "1500x12",
            "name_ar": "مياه 1500 مل × 12 زجاجة",
            "name_en": "Water 1500ml × 12 bottles",
            "bottle_volume_ml": 1500,
            "bottles_per_carton": 12,
            "bom": [
                ("PREFORM_30G", 12),
                ("CAPS_1_7G", 12),
                ("LABEL_1500ML", 12),
                ("SHRINK_560M", 0.50),
            ],
        },
        {
            "code": "330x30",
            "name_ar": "مياه 330 مل × 30 زجاجة",
            "name_en": "Water 330ml × 30 bottles",
            "bottle_volume_ml": 330,
            "bottles_per_carton": 30,
            "bom": [
                ("PREFORM_11_7G", 30),
                ("CAPS_1_7G", 30),
                ("LABEL_330ML", 30),
                ("SHRINK_470M", 0.57),
            ],
        },
        {
            "code": "750x12",
            "name_ar": "مياه 750 مل × 12 زجاجة",
            "name_en": "Water 750ml × 12 bottles",
            "bottle_volume_ml": 750,
            "bottles_per_carton": 12,
            "bom": [
                ("PREFORM_20_5G", 12),
                ("CAPS_1_7G", 12),
                ("LABEL_750ML", 12),
                ("SHRINK_470M", 0.50),
            ],
        },
    ]

    for pd in products_data:
        product = db.query(models.Product).filter(models.Product.code == pd["code"]).first()
        if not product:
            product = models.Product(
                code=pd["code"],
                name_ar=pd["name_ar"],
                name_en=pd["name_en"],
                bottle_volume_ml=pd["bottle_volume_ml"],
                bottles_per_carton=pd["bottles_per_carton"],
            )
            db.add(product)
            db.flush()

        for item_code, qty in pd["bom"]:
            item = _get_item(db, item_code)
            if not item:
                continue
            existing_bom = (
                db.query(models.ProductBOMLine)
                .filter(
                    models.ProductBOMLine.product_id == product.id,
                    models.ProductBOMLine.item_id == item.id,
                )
                .first()
            )
            if not existing_bom:
                db.add(
                    models.ProductBOMLine(
                        product_id=product.id,
                        item_id=item.id,
                        qty_per_carton=qty,
                    )
                )
    db.commit()


def main(username="admin", password="Admin1234", full_name="System Admin"):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    ensure_roles_and_units(db)
    ensure_warehouses_and_items(db)
    ensure_products_and_bom(db)

    user = db.query(models.AppUser).filter(models.AppUser.username == username).first()
    admin_role = db.query(models.Role).filter(models.Role.name == "admin").first()
    if user:
        print(f"User '{username}' already exists.")
        return

    user = models.AppUser(
        username=username,
        full_name=full_name,
        preferred_locale="ar",
        password_hash=hash_password(password),
        is_active=True,
    )
    db.add(user)
    db.flush()
    user.roles.append(admin_role)
    db.commit()
    print(f"Created admin user: {username}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--username", default="admin")
    parser.add_argument("--password", default="Admin1234")
    parser.add_argument("--full-name", default="System Admin")
    args = parser.parse_args()

    main(username=args.username, password=args.password, full_name=args.full_name)
