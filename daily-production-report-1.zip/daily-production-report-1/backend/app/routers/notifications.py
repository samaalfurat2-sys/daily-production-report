from __future__ import annotations

import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import func

from app import models
from app.deps import get_db, get_current_user

router = APIRouter(prefix="/notifications", tags=["notifications"])


class NotificationOut(BaseModel):
    id: uuid.UUID
    category: str
    title_ar: str
    title_en: str
    body_ar: Optional[str] = None
    body_en: Optional[str] = None
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
    is_read: bool
    created_at: str


class NotificationCountOut(BaseModel):
    unread: int
    total: int


@router.get("", response_model=List[NotificationOut])
def list_notifications(
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
    unread_only: bool = Query(default=False),
    limit: int = Query(default=50, ge=1, le=200),
):
    q = db.query(models.Notification).filter(models.Notification.user_id == user.id)
    if unread_only:
        q = q.filter(models.Notification.is_read == False)
    rows = q.order_by(models.Notification.created_at.desc()).limit(limit).all()
    return [
        NotificationOut(
            id=n.id,
            category=n.category,
            title_ar=n.title_ar,
            title_en=n.title_en,
            body_ar=n.body_ar,
            body_en=n.body_en,
            entity_type=n.entity_type,
            entity_id=n.entity_id,
            is_read=n.is_read,
            created_at=n.created_at.isoformat(),
        )
        for n in rows
    ]


@router.get("/count", response_model=NotificationCountOut)
def notification_count(
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    unread = db.query(func.count(models.Notification.id)).filter(
        models.Notification.user_id == user.id,
        models.Notification.is_read == False,
    ).scalar()
    total = db.query(func.count(models.Notification.id)).filter(
        models.Notification.user_id == user.id,
    ).scalar()
    return NotificationCountOut(unread=unread or 0, total=total or 0)


@router.post("/{notification_id}/read")
def mark_read(
    notification_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    n = db.query(models.Notification).filter(
        models.Notification.id == notification_id,
        models.Notification.user_id == user.id,
    ).first()
    if not n:
        raise HTTPException(status_code=404, detail="Notification not found")
    n.is_read = True
    db.commit()
    return {"ok": True}


@router.post("/read-all")
def mark_all_read(
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    db.query(models.Notification).filter(
        models.Notification.user_id == user.id,
        models.Notification.is_read == False,
    ).update({"is_read": True})
    db.commit()
    return {"ok": True}
