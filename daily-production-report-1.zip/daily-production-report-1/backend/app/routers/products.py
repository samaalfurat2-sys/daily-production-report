from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models
from app.deps import get_db, get_current_user
from app.schemas import ProductOut, BOMLineOut

router = APIRouter(prefix="/products", tags=["products"])


def _product_to_out(p: models.Product) -> ProductOut:
    return ProductOut(
        id=p.id,
        code=p.code,
        name_ar=p.name_ar,
        name_en=p.name_en,
        bottle_volume_ml=p.bottle_volume_ml,
        bottles_per_carton=p.bottles_per_carton,
        is_active=p.is_active,
        bom_lines=[
            BOMLineOut(
                id=bl.id,
                item_code=bl.item.code,
                item_name_ar=bl.item.name_ar,
                item_name_en=bl.item.name_en,
                uom=bl.item.uom,
                qty_per_carton=float(bl.qty_per_carton),
            )
            for bl in p.bom_lines
        ],
    )


@router.get("", response_model=List[ProductOut])
def list_products(
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    rows = db.query(models.Product).order_by(models.Product.code).all()
    return [_product_to_out(r) for r in rows]


@router.get("/{product_code}", response_model=ProductOut)
def get_product(
    product_code: str,
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    p = db.query(models.Product).filter(models.Product.code == product_code).first()
    if not p:
        raise HTTPException(status_code=404, detail=f"Product not found: {product_code}")
    return _product_to_out(p)
