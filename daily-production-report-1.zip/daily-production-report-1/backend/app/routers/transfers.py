from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, case

from app import models
from app.deps import get_db, get_current_user, require_roles, user_roles
from app.schemas import (
    StockTransferCreate,
    StockTransferOut,
    TransferLineOut,
    TransferRespondRequest,
)
from app.inventory import create_inventory_txn
from app.ws_manager import broadcast_event
from app.notifications import notify_transfer_created, notify_transfer_responded

router = APIRouter(prefix="/transfers", tags=["transfers"])


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _get_warehouse_or_404(db: Session, code: str) -> models.Warehouse:
    wh = db.query(models.Warehouse).filter(models.Warehouse.code == code).first()
    if not wh:
        raise HTTPException(status_code=404, detail=f"Warehouse not found: {code}")
    return wh


def _get_item_or_404(db: Session, code: str) -> models.InventoryItem:
    item = db.query(models.InventoryItem).filter(models.InventoryItem.code == code).first()
    if not item:
        raise HTTPException(status_code=404, detail=f"Item not found: {code}")
    return item


def _next_transfer_number(db: Session) -> str:
    max_seq = (
        db.query(func.count(models.StockTransfer.id)).scalar() or 0
    )
    seq = max_seq + 1
    while True:
        candidate = f"TRF-{seq:06d}"
        exists = db.query(
            db.query(models.StockTransfer)
            .filter(models.StockTransfer.transfer_number == candidate)
            .exists()
        ).scalar()
        if not exists:
            return candidate
        seq += 1


def _stock_on_hand(db: Session, warehouse_id: uuid.UUID, item_id: uuid.UUID) -> float:
    result = (
        db.query(
            func.coalesce(
                func.sum(
                    case(
                        (
                            models.InventoryTransaction.txn_type.in_(["RECEIVE", "ADJUST"]),
                            models.InventoryTransaction.qty,
                        ),
                        else_=-models.InventoryTransaction.qty,
                    )
                ),
                0,
            )
        )
        .filter(
            models.InventoryTransaction.warehouse_id == warehouse_id,
            models.InventoryTransaction.item_id == item_id,
        )
        .scalar()
    )
    return float(result or 0)


def _transfer_to_out(t: models.StockTransfer) -> StockTransferOut:
    return StockTransferOut(
        id=t.id,
        transfer_number=t.transfer_number,
        from_warehouse_code=t.from_warehouse.code,
        from_warehouse_name_ar=t.from_warehouse.name_ar,
        from_warehouse_name_en=t.from_warehouse.name_en,
        to_warehouse_code=t.to_warehouse.code,
        to_warehouse_name_ar=t.to_warehouse.name_ar,
        to_warehouse_name_en=t.to_warehouse.name_en,
        status=t.status,
        note=t.note,
        issued_by_username=t.issuer.username,
        issued_by_full_name=t.issuer.full_name,
        issued_at=t.issued_at,
        responded_by_username=t.responder.username if t.responder else None,
        responded_by_full_name=t.responder.full_name if t.responder else None,
        responded_at=t.responded_at,
        response_note=t.response_note,
        lines=[
            TransferLineOut(
                id=line.id,
                item_code=line.item.code,
                item_name_ar=line.item.name_ar,
                item_name_en=line.item.name_en,
                uom=line.item.uom,
                qty=float(line.qty),
            )
            for line in t.lines
        ],
    )


@router.post("", response_model=StockTransferOut, status_code=201)
def create_transfer(
    payload: StockTransferCreate,
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(
        require_roles("admin", "warehouse_clerk", "warehouse_supervisor")
    ),
):
    if payload.from_warehouse_code == payload.to_warehouse_code:
        raise HTTPException(
            status_code=400,
            detail="Source and destination warehouse must be different.",
        )

    from_wh = _get_warehouse_or_404(db, payload.from_warehouse_code)
    to_wh = _get_warehouse_or_404(db, payload.to_warehouse_code)

    transfer = models.StockTransfer(
        transfer_number=_next_transfer_number(db),
        from_warehouse_id=from_wh.id,
        to_warehouse_id=to_wh.id,
        status="PENDING",
        note=payload.note,
        issued_by=user.id,
    )

    for line_in in payload.lines:
        item = _get_item_or_404(db, line_in.item_code)
        on_hand = _stock_on_hand(db, from_wh.id, item.id)
        if on_hand < line_in.qty:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Insufficient stock for {item.code} in {from_wh.code}: "
                    f"available {on_hand}, requested {line_in.qty}"
                ),
            )
        transfer.lines.append(
            models.StockTransferLine(item_id=item.id, qty=line_in.qty)
        )

    db.add(transfer)
    db.flush()
    notify_transfer_created(db, transfer, user)
    db.commit()
    db.refresh(transfer)
    result = _transfer_to_out(transfer)
    broadcast_event("created", "transfer", {"id": str(transfer.id), "transfer_number": transfer.transfer_number, "from": payload.from_warehouse_code, "to": payload.to_warehouse_code, "status": "PENDING"})
    return result


@router.get("", response_model=List[StockTransferOut])
def list_transfers(
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
    status: Optional[str] = Query(default=None),
    from_warehouse_code: Optional[str] = Query(default=None),
    to_warehouse_code: Optional[str] = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
):
    q = db.query(models.StockTransfer)
    if status:
        q = q.filter(models.StockTransfer.status == status)
    if from_warehouse_code:
        q = q.join(
            models.Warehouse,
            models.StockTransfer.from_warehouse_id == models.Warehouse.id,
        ).filter(models.Warehouse.code == from_warehouse_code)
    if to_warehouse_code:
        wh_to = db.query(models.Warehouse).filter(
            models.Warehouse.code == to_warehouse_code
        ).first()
        if wh_to:
            q = q.filter(models.StockTransfer.to_warehouse_id == wh_to.id)

    rows = q.order_by(models.StockTransfer.issued_at.desc()).limit(limit).all()
    return [_transfer_to_out(r) for r in rows]


@router.get("/{transfer_id}", response_model=StockTransferOut)
def get_transfer(
    transfer_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    t = db.get(models.StockTransfer, transfer_id)
    if not t:
        raise HTTPException(status_code=404, detail="Transfer not found.")
    return _transfer_to_out(t)


@router.post("/{transfer_id}/respond", response_model=StockTransferOut)
def respond_to_transfer(
    transfer_id: uuid.UUID,
    body: TransferRespondRequest,
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(
        require_roles("admin", "warehouse_clerk", "warehouse_supervisor")
    ),
):
    t = db.get(models.StockTransfer, transfer_id)
    if not t:
        raise HTTPException(status_code=404, detail="Transfer not found.")
    if t.status != "PENDING":
        raise HTTPException(
            status_code=400,
            detail=f"Transfer is already {t.status}, cannot respond again.",
        )

    roles = user_roles(user)
    is_admin = "admin" in roles
    if not is_admin and t.issued_by == user.id:
        raise HTTPException(
            status_code=403,
            detail="The issuer of a transfer cannot also respond to it.",
        )

    now = _utcnow()
    t.status = body.action
    t.responded_by = user.id
    t.responded_at = now
    t.response_note = body.response_note

    if body.action == "ACCEPTED":
        for line in t.lines:
            on_hand = _stock_on_hand(db, t.from_warehouse_id, line.item_id)
            if on_hand < float(line.qty):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Insufficient stock for {line.item.code} in "
                        f"{t.from_warehouse.code}: available {on_hand}, "
                        f"requested {float(line.qty)}"
                    ),
                )

            create_inventory_txn(
                db,
                warehouse=t.from_warehouse,
                item=line.item,
                txn_type="ISSUE",
                qty=float(line.qty),
                txn_date=now.date(),
                created_by=user.id,
                reference_type="STOCK_TRANSFER",
                reference_id=str(t.id),
                note=f"Transfer {t.transfer_number} to {t.to_warehouse.code}",
            )

            create_inventory_txn(
                db,
                warehouse=t.to_warehouse,
                item=line.item,
                txn_type="RECEIVE",
                qty=float(line.qty),
                txn_date=now.date(),
                created_by=user.id,
                reference_type="STOCK_TRANSFER",
                reference_id=str(t.id),
                note=f"Transfer {t.transfer_number} from {t.from_warehouse.code}",
            )

    notify_transfer_responded(db, t, user)
    db.commit()
    db.refresh(t)
    result = _transfer_to_out(t)
    broadcast_event("responded", "transfer", {"id": str(t.id), "transfer_number": t.transfer_number, "status": t.status, "from": t.from_warehouse.code, "to": t.to_warehouse.code})
    if body.action == "ACCEPTED":
        broadcast_event("updated", "inventory", {"reason": "transfer_accepted", "transfer_id": str(t.id)})
    return result
