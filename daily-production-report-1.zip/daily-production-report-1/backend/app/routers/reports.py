from __future__ import annotations

import uuid
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session
from sqlalchemy import func, case

from app import models
from app.deps import get_db, get_current_user
from app.pdf_reports import (
    generate_warehouse_inventory_report,
    generate_transfers_report,
    generate_shift_production_report,
)
from app.production import calculate_shift_consumption, _stock_on_hand_wh2

router = APIRouter(prefix="/reports", tags=["reports"])


def _pdf_response(pdf_bytes: bytes, filename: str) -> Response:
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'},
    )


def _model_to_dict(obj):
    if obj is None:
        return None
    data = {}
    for col in obj.__table__.columns:
        val = getattr(obj, col.name, None)
        data[col.name] = val
    return data


@router.get("/warehouse/{warehouse_code}")
def warehouse_inventory_report(
    warehouse_code: str,
    date_from: Optional[date] = Query(default=None),
    date_to: Optional[date] = Query(default=None),
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    wh = db.query(models.Warehouse).filter(models.Warehouse.code == warehouse_code).first()
    if not wh:
        raise HTTPException(status_code=404, detail=f"Warehouse not found: {warehouse_code}")

    txn_q = (
        db.query(models.InventoryTransaction)
        .filter(models.InventoryTransaction.warehouse_id == wh.id)
    )
    if date_from:
        txn_q = txn_q.filter(models.InventoryTransaction.txn_date >= date_from)
    if date_to:
        txn_q = txn_q.filter(models.InventoryTransaction.txn_date <= date_to)
    txn_q = txn_q.order_by(
        models.InventoryTransaction.txn_date.desc(),
        models.InventoryTransaction.created_at.desc(),
    )
    txns = txn_q.all()

    transactions = []
    for tx in txns:
        transactions.append({
            "txn_date": tx.txn_date,
            "txn_type": tx.txn_type,
            "item_code": tx.item.code,
            "item_name_ar": tx.item.name_ar,
            "qty": float(tx.qty),
            "reference_type": tx.reference_type,
            "note": tx.note,
        })

    stock_q = (
        db.query(
            models.InventoryItem.code,
            models.InventoryItem.name_ar,
            models.InventoryItem.uom,
            func.sum(
                case(
                    (models.InventoryTransaction.txn_type.in_(["RECEIVE", "ADJUST"]),
                     models.InventoryTransaction.qty),
                    else_=-models.InventoryTransaction.qty,
                )
            ).label("qty"),
        )
        .join(models.InventoryTransaction, models.InventoryTransaction.item_id == models.InventoryItem.id)
        .filter(models.InventoryTransaction.warehouse_id == wh.id)
        .group_by(models.InventoryItem.code, models.InventoryItem.name_ar, models.InventoryItem.uom)
        .order_by(models.InventoryItem.code)
        .all()
    )

    stock_rows = [
        {"item_code": r[0], "item_name_ar": r[1], "uom": r[2], "qty_on_hand": float(r[3] or 0)}
        for r in stock_q
        if float(r[3] or 0) != 0
    ]

    pdf = generate_warehouse_inventory_report(
        warehouse_code=wh.code,
        warehouse_name_ar=wh.name_ar,
        warehouse_name_en=wh.name_en,
        transactions=transactions,
        stock_rows=stock_rows,
        date_from=date_from,
        date_to=date_to,
    )

    filename = f"warehouse_{warehouse_code}_{date_from or 'all'}_{date_to or 'now'}.pdf"
    return _pdf_response(pdf, filename)


@router.get("/warehouses/all")
def all_warehouses_report(
    date_from: Optional[date] = Query(default=None),
    date_to: Optional[date] = Query(default=None),
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    from reportlab.platypus import SimpleDocTemplate, PageBreak
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    import io

    warehouses = db.query(models.Warehouse).order_by(models.Warehouse.code).all()
    if not warehouses:
        raise HTTPException(status_code=404, detail="No warehouses found")

    from app.pdf_reports import (
        _styles, _ar, _fmt, _table_style, _footer,
        FONT_NAME, FONT_BOLD, GRID_COLOR, A4 as _A4,
    )
    from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=15 * mm, bottomMargin=20 * mm,
    )
    ss = _styles()
    elements = []

    for idx, wh in enumerate(warehouses):
        if idx > 0:
            elements.append(PageBreak())

        title_ar = _ar(f"تقرير مستودع {wh.name_ar}")
        elements.append(Paragraph(title_ar, ss["TitleAr"]))
        elements.append(Paragraph(f"Warehouse: {wh.name_en} ({wh.code})", ss["TitleEn"]))
        elements.append(Spacer(1, 4 * mm))

        stock_q = (
            db.query(
                models.InventoryItem.code,
                models.InventoryItem.name_ar,
                models.InventoryItem.uom,
                func.sum(
                    case(
                        (models.InventoryTransaction.txn_type.in_(["RECEIVE", "ADJUST"]),
                         models.InventoryTransaction.qty),
                        else_=-models.InventoryTransaction.qty,
                    )
                ).label("qty"),
            )
            .join(models.InventoryTransaction, models.InventoryTransaction.item_id == models.InventoryItem.id)
            .filter(models.InventoryTransaction.warehouse_id == wh.id)
            .group_by(models.InventoryItem.code, models.InventoryItem.name_ar, models.InventoryItem.uom)
            .order_by(models.InventoryItem.code)
            .all()
        )
        stock_rows = [r for r in stock_q if float(r[3] or 0) != 0]

        elements.append(Paragraph(_ar("المخزون الحالي") + " / Stock on Hand", ss["SubHead"]))
        if stock_rows:
            hdr = ["#", "Item Code", _ar("اسم الصنف"), "UOM", "Qty"]
            data = [hdr]
            for i, r in enumerate(stock_rows, 1):
                data.append([str(i), r[0], _ar(r[1]), r[2], _fmt(float(r[3] or 0))])
            col_w = [8 * mm, 35 * mm, 55 * mm, 20 * mm, 30 * mm]
            t = Table(data, colWidths=col_w, repeatRows=1)
            t.setStyle(_table_style(len(data), len(hdr)))
            elements.append(t)
        else:
            elements.append(Paragraph("No stock on hand.", ss["MetaText"]))

        txn_q = (
            db.query(models.InventoryTransaction)
            .filter(models.InventoryTransaction.warehouse_id == wh.id)
        )
        if date_from:
            txn_q = txn_q.filter(models.InventoryTransaction.txn_date >= date_from)
        if date_to:
            txn_q = txn_q.filter(models.InventoryTransaction.txn_date <= date_to)
        txns = txn_q.order_by(
            models.InventoryTransaction.txn_date.desc(),
            models.InventoryTransaction.created_at.desc(),
        ).limit(200).all()

        elements.append(Spacer(1, 4 * mm))
        elements.append(Paragraph(_ar("حركات المستودع") + " / Transactions", ss["SubHead"]))
        if txns:
            hdr = ["#", "Date", "Type", "Item", _ar("الصنف"), "Qty", "Ref", "Note"]
            data = [hdr]
            for i, tx in enumerate(txns, 1):
                data.append([
                    str(i), str(tx.txn_date), tx.txn_type,
                    tx.item.code, _ar(tx.item.name_ar),
                    _fmt(float(tx.qty)), tx.reference_type or "",
                    (tx.note or "")[:35],
                ])
            col_w = [7 * mm, 22 * mm, 16 * mm, 28 * mm, 35 * mm, 18 * mm, 22 * mm, 35 * mm]
            t = Table(data, colWidths=col_w, repeatRows=1)
            t.setStyle(_table_style(len(data), len(hdr)))
            elements.append(t)
        else:
            elements.append(Paragraph("No transactions in period.", ss["MetaText"]))

    doc.build(elements, onFirstPage=lambda c, d: _footer(c, d, "All Warehouses Report"),
              onLaterPages=lambda c, d: _footer(c, d, "All Warehouses Report"))

    filename = f"all_warehouses_{date_from or 'all'}_{date_to or 'now'}.pdf"
    return _pdf_response(buf.getvalue(), filename)


@router.get("/transfers")
def transfers_report(
    warehouse_code: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    date_from: Optional[date] = Query(default=None),
    date_to: Optional[date] = Query(default=None),
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    q = db.query(models.StockTransfer)
    if warehouse_code:
        wh = db.query(models.Warehouse).filter(models.Warehouse.code == warehouse_code).first()
        if wh:
            q = q.filter(
                (models.StockTransfer.from_warehouse_id == wh.id) |
                (models.StockTransfer.to_warehouse_id == wh.id)
            )
    if status:
        q = q.filter(models.StockTransfer.status == status)
    if date_from:
        q = q.filter(func.date(models.StockTransfer.issued_at) >= date_from)
    if date_to:
        q = q.filter(func.date(models.StockTransfer.issued_at) <= date_to)

    rows = q.order_by(models.StockTransfer.issued_at.desc()).limit(500).all()

    transfers = []
    for t in rows:
        transfers.append({
            "transfer_number": t.transfer_number,
            "from_warehouse_code": t.from_warehouse.code,
            "to_warehouse_code": t.to_warehouse.code,
            "status": t.status,
            "issued_by_username": t.issuer.username if t.issuer else "",
            "issued_at": t.issued_at,
            "lines": [
                {"item_code": ln.item.code, "qty": float(ln.qty)}
                for ln in t.lines
            ],
        })

    pdf = generate_transfers_report(
        transfers=transfers,
        warehouse_code=warehouse_code,
        date_from=date_from,
        date_to=date_to,
    )
    filename = f"transfers_{warehouse_code or 'all'}_{date_from or 'all'}_{date_to or 'now'}.pdf"
    return _pdf_response(pdf, filename)


@router.get("/shift/{shift_id}")
def shift_production_report(
    shift_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: models.AppUser = Depends(get_current_user),
):
    shift = db.query(models.ShiftRecord).filter(models.ShiftRecord.id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=404, detail="Shift not found")

    shift_data = {
        "report_date": shift.report_date,
        "shift_code": shift.shift_code,
        "status": shift.status,
        "blow": _model_to_dict(shift.blow),
        "filling": _model_to_dict(shift.filling),
        "label": _model_to_dict(shift.label),
        "shrink": _model_to_dict(shift.shrink),
        "diesel": _model_to_dict(shift.diesel),
    }

    production_lines = []
    for pl in (shift.production_lines or []):
        production_lines.append({
            "product_code": pl.product.code,
            "product_name_ar": pl.product.name_ar,
            "product_name_en": pl.product.name_en,
            "bottles_per_carton": pl.product.bottles_per_carton,
            "bottle_volume_ml": pl.product.bottle_volume_ml,
            "cartons_produced": float(pl.cartons_produced or 0),
        })

    required, _ = calculate_shift_consumption(db, shift)
    consumption = []
    for item_code, total_needed in required.items():
        item = db.query(models.InventoryItem).filter(
            models.InventoryItem.code == item_code
        ).first()
        if not item:
            continue
        on_hand = _stock_on_hand_wh2(db, item.id)
        consumed = min(on_hand, total_needed)
        missing = total_needed - consumed
        consumption.append({
            "item_code": item_code,
            "item_name_ar": item.name_ar,
            "uom": item.uom,
            "total_required": round(total_needed, 3),
            "wh2_on_hand": round(on_hand, 3),
            "consumed_from_wh2": round(consumed, 3),
            "missing_to_wh2_1": round(missing, 3),
        })

    finished = {}
    for pl in (shift.production_lines or []):
        cartons = float(pl.cartons_produced or 0)
        if cartons > 0:
            finished[f"FP_{pl.product.code}"] = cartons

    pdf = generate_shift_production_report(
        shift_data=shift_data,
        production_lines=production_lines,
        consumption=consumption,
        finished_cartons=finished,
    )
    filename = f"shift_{shift.shift_code}_{shift.report_date}.pdf"
    return _pdf_response(pdf, filename)
