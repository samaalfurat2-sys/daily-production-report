from __future__ import annotations

import uuid
from typing import List, Optional

from sqlalchemy.orm import Session

from app import models
from app.ws_manager import push_to_users


def _get_users_with_roles(db: Session, *role_names: str, exclude_user_id=None) -> List[models.AppUser]:
    users = (
        db.query(models.AppUser)
        .join(models.AppUser.roles)
        .filter(models.Role.name.in_(role_names))
        .filter(models.AppUser.is_active == True)
        .all()
    )
    seen = set()
    result = []
    for u in users:
        if u.id in seen:
            continue
        if exclude_user_id and u.id == exclude_user_id:
            continue
        seen.add(u.id)
        result.append(u)
    return result


def _create_and_push(
    db: Session,
    recipients: List[models.AppUser],
    category: str,
    title_ar: str,
    title_en: str,
    body_ar: str = "",
    body_en: str = "",
    entity_type: str | None = None,
    entity_id: str | None = None,
):
    if not recipients:
        return

    user_ids = []
    for user in recipients:
        notif = models.Notification(
            user_id=user.id,
            category=category,
            title_ar=title_ar,
            title_en=title_en,
            body_ar=body_ar,
            body_en=body_en,
            entity_type=entity_type,
            entity_id=entity_id,
        )
        db.add(notif)
        user_ids.append(str(user.id))

    db.flush()

    push_to_users(
        user_ids,
        event="notification",
        entity=category,
        data={
            "title_ar": title_ar,
            "title_en": title_en,
            "body_ar": body_ar,
            "body_en": body_en,
            "entity_type": entity_type,
            "entity_id": entity_id,
        },
    )


def notify_transfer_created(
    db: Session,
    transfer: models.StockTransfer,
    issuer: models.AppUser,
):
    to_wh = transfer.to_warehouse
    recipients = _get_users_with_roles(
        db, "warehouse_clerk", "warehouse_supervisor", "admin",
        exclude_user_id=issuer.id,
    )

    _create_and_push(
        db, recipients,
        category="transfer",
        title_ar=f"تحويل جديد إلى {to_wh.name_ar}",
        title_en=f"New transfer to {to_wh.name_en}",
        body_ar=f"تحويل {transfer.transfer_number} من {transfer.from_warehouse.name_ar} إلى {to_wh.name_ar} بانتظار الموافقة",
        body_en=f"Transfer {transfer.transfer_number} from {transfer.from_warehouse.name_en} to {to_wh.name_en} pending approval",
        entity_type="transfer",
        entity_id=str(transfer.id),
    )


def notify_transfer_responded(
    db: Session,
    transfer: models.StockTransfer,
    responder: models.AppUser,
):
    issuer = transfer.issuer
    status_ar = "مقبول" if transfer.status == "ACCEPTED" else "مرفوض"
    status_en = transfer.status.lower()

    recipients = [issuer] if issuer and issuer.id != responder.id else []

    _create_and_push(
        db, recipients,
        category="transfer",
        title_ar=f"تحويل {transfer.transfer_number} {status_ar}",
        title_en=f"Transfer {transfer.transfer_number} {status_en}",
        body_ar=f"تم {'قبول' if transfer.status == 'ACCEPTED' else 'رفض'} التحويل من {transfer.from_warehouse.name_ar} إلى {transfer.to_warehouse.name_ar} بواسطة {responder.full_name or responder.username}",
        body_en=f"Transfer from {transfer.from_warehouse.name_en} to {transfer.to_warehouse.name_en} was {status_en} by {responder.full_name or responder.username}",
        entity_type="transfer",
        entity_id=str(transfer.id),
    )


def notify_shift_submitted(
    db: Session,
    shift: models.ShiftRecord,
    submitter: models.AppUser,
):
    recipients = _get_users_with_roles(
        db, "supervisor", "warehouse_supervisor",
        exclude_user_id=submitter.id,
    )

    _create_and_push(
        db, recipients,
        category="shift",
        title_ar=f"وردية {shift.shift_code} بتاريخ {shift.report_date} مقدمة للاعتماد",
        title_en=f"Shift {shift.shift_code} on {shift.report_date} submitted for approval",
        body_ar=f"قدم {submitter.full_name or submitter.username} الوردية {shift.shift_code} للاعتماد",
        body_en=f"{submitter.full_name or submitter.username} submitted shift {shift.shift_code} for approval",
        entity_type="shift",
        entity_id=str(shift.id),
    )


def notify_shift_approved(
    db: Session,
    shift: models.ShiftRecord,
    approver: models.AppUser,
):
    creator_ids = set()
    if shift.created_by:
        creator_ids.add(shift.created_by)
    if shift.submitted_by:
        creator_ids.add(shift.submitted_by)
    creator_ids.discard(approver.id)

    recipients = [
        db.get(models.AppUser, uid)
        for uid in creator_ids
    ]
    recipients = [r for r in recipients if r]

    _create_and_push(
        db, recipients,
        category="shift",
        title_ar=f"وردية {shift.shift_code} بتاريخ {shift.report_date} تمت الموافقة",
        title_en=f"Shift {shift.shift_code} on {shift.report_date} approved",
        body_ar=f"اعتمد {approver.full_name or approver.username} الوردية {shift.shift_code} وتم ترحيل المخزون",
        body_en=f"{approver.full_name or approver.username} approved shift {shift.shift_code} and inventory was posted",
        entity_type="shift",
        entity_id=str(shift.id),
    )


def notify_shift_locked(
    db: Session,
    shift: models.ShiftRecord,
    locker: models.AppUser,
):
    creator_ids = set()
    if shift.created_by:
        creator_ids.add(shift.created_by)
    if shift.submitted_by:
        creator_ids.add(shift.submitted_by)
    if shift.approved_by:
        creator_ids.add(shift.approved_by)
    creator_ids.discard(locker.id)

    recipients = [db.get(models.AppUser, uid) for uid in creator_ids]
    recipients = [r for r in recipients if r]

    _create_and_push(
        db, recipients,
        category="shift",
        title_ar=f"وردية {shift.shift_code} بتاريخ {shift.report_date} مقفلة",
        title_en=f"Shift {shift.shift_code} on {shift.report_date} locked",
        body_ar=f"قفل {locker.full_name or locker.username} الوردية {shift.shift_code}",
        body_en=f"{locker.full_name or locker.username} locked shift {shift.shift_code}",
        entity_type="shift",
        entity_id=str(shift.id),
    )


def notify_inventory_transaction(
    db: Session,
    txn: models.InventoryTransaction,
    actor: models.AppUser,
):
    recipients = _get_users_with_roles(
        db, "warehouse_clerk", "warehouse_supervisor",
        exclude_user_id=actor.id,
    )

    wh_code = txn.warehouse.code
    item_code = txn.item.code
    _create_and_push(
        db, recipients,
        category="inventory",
        title_ar=f"حركة مخزون جديدة في {wh_code}",
        title_en=f"New inventory transaction in {wh_code}",
        body_ar=f"{txn.txn_type} {item_code} كمية {float(txn.qty)} في {txn.warehouse.name_ar}",
        body_en=f"{txn.txn_type} {item_code} qty {float(txn.qty)} in {txn.warehouse.name_en}",
        entity_type="inventory_transaction",
        entity_id=str(txn.id),
    )
