from __future__ import annotations

import asyncio
import json
import logging
import threading
from datetime import datetime, timezone
from typing import Any, Dict

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        self._connections: Dict[str, WebSocket] = {}
        self._user_ids: Dict[str, str] = {}
        self._lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_loop(self, loop: asyncio.AbstractEventLoop):
        self._loop = loop

    async def connect(self, websocket: WebSocket, client_id: str, user_id: str):
        await websocket.accept()
        if self._loop is None:
            self._loop = asyncio.get_running_loop()
        async with self._lock:
            self._connections[client_id] = websocket
            self._user_ids[client_id] = user_id
        logger.info("WS connected: client=%s user=%s (total=%d)", client_id, user_id, len(self._connections))

    async def disconnect(self, client_id: str):
        async with self._lock:
            self._connections.pop(client_id, None)
            self._user_ids.pop(client_id, None)
        logger.info("WS disconnected: client=%s (total=%d)", client_id, len(self._connections))

    async def broadcast(self, event: str, entity: str, data: Any = None, exclude_client: str | None = None):
        message = json.dumps({
            "event": event,
            "entity": entity,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, default=str)

        async with self._lock:
            targets = {
                cid: ws for cid, ws in self._connections.items()
                if cid != exclude_client
            }

        stale: list[str] = []
        for cid, ws in targets.items():
            try:
                await ws.send_text(message)
            except Exception:
                stale.append(cid)

        for cid in stale:
            await self.disconnect(cid)

    async def send_to_user(self, user_id: str, event: str, entity: str, data: Any = None):
        message = json.dumps({
            "event": event,
            "entity": entity,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, default=str)

        async with self._lock:
            targets = {
                cid: ws for cid, ws in self._connections.items()
                if self._user_ids.get(cid) == user_id
            }

        stale: list[str] = []
        for cid, ws in targets.items():
            try:
                await ws.send_text(message)
            except Exception:
                stale.append(cid)

        for cid in stale:
            await self.disconnect(cid)

    async def send_to_users(self, user_ids: list[str], event: str, entity: str, data: Any = None):
        user_set = set(user_ids)
        message = json.dumps({
            "event": event,
            "entity": entity,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, default=str)

        async with self._lock:
            targets = {
                cid: ws for cid, ws in self._connections.items()
                if self._user_ids.get(cid) in user_set
            }

        stale: list[str] = []
        for cid, ws in targets.items():
            try:
                await ws.send_text(message)
            except Exception:
                stale.append(cid)

        for cid in stale:
            await self.disconnect(cid)

    @property
    def active_count(self) -> int:
        return len(self._connections)


manager = ConnectionManager()


def _schedule(coro):
    loop = manager._loop
    if loop is None:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
    if threading.current_thread() is threading.main_thread():
        try:
            asyncio.get_running_loop()
            loop.create_task(coro)
        except RuntimeError:
            pass
    else:
        asyncio.run_coroutine_threadsafe(coro, loop)


def broadcast_event(event: str, entity: str, data: Any = None):
    _schedule(manager.broadcast(event, entity, data))


def push_to_users(user_ids: list[str], event: str, entity: str, data: Any = None):
    _schedule(manager.send_to_users(user_ids, event, entity, data))
