from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserInfo(BaseModel):
    id: uuid.UUID
    username: str
    full_name: Optional[str] = None
    preferred_locale: str = "ar"
    roles: List[str] = []
    unit_permissions: Dict[str, bool] = {}


class ShiftCreate(BaseModel):
    report_date: date
    shift_code: str = Field(min_length=1, max_length=10)


class ShiftBase(BaseModel):
    id: uuid.UUID
    report_date: date
    shift_code: str
    status: str
    notes: Optional[str] = None
    created_at: datetime


class BlowReportIn(BaseModel):
    preforms_per_carton: int = 1248
    prev_cartons: Optional[float] = None
    received_cartons: Optional[float] = None
    next_cartons: Optional[float] = None
    product_cartons: Optional[float] = None
    waste_preforms_pcs: Optional[int] = None
    waste_scrap_pcs: Optional[int] = None
    waste_bottles_pcs: Optional[int] = None
    counter_value: Optional[int] = None
    stock075_issued: Optional[float] = None
    stock075_received: Optional[float] = None
    stock15_issued: Optional[float] = None
    stock15_received: Optional[float] = None


class FillingReportIn(BaseModel):
    caps_per_carton: int = 5500
    prev_cartons: Optional[float] = None
    received_cartons: Optional[float] = None
    next_cartons: Optional[float] = None
    waste_caps_pcs: Optional[int] = None
    waste_scrap_pcs: Optional[int] = None
    waste_bottles_pcs: Optional[int] = None
    counter_value: Optional[int] = None
    stock_issued: Optional[float] = None
    stock_received: Optional[float] = None


class LabelReportIn(BaseModel):
    labels_per_roll: int = 23000
    prev_rolls: Optional[float] = None
    received_rolls: Optional[float] = None
    next_rolls: Optional[float] = None
    waste_grams: Optional[float] = None
    stock075_issued: Optional[float] = None
    stock075_received: Optional[float] = None
    stock15_issued: Optional[float] = None
    stock15_received: Optional[float] = None


class ShrinkReportIn(BaseModel):
    kg_per_roll: float = 25
    kg_per_carton: float = 0.055
    prev_rolls: Optional[float] = None
    received_rolls: Optional[float] = None
    next_rolls: Optional[float] = None
    waste_kg: Optional[float] = None
    screen_counter: Optional[int] = None
    stock075_issued: Optional[float] = None
    stock075_received: Optional[float] = None
    stock15_issued: Optional[float] = None
    stock15_received: Optional[float] = None


class DieselReportIn(BaseModel):
    generator1_total_reading: Optional[float] = None
    generator1_consumed: Optional[float] = None
    generator2_total_reading: Optional[float] = None
    generator2_consumed: Optional[float] = None
    main_tank_received: Optional[float] = None


class ProductionLineIn(BaseModel):
    product_code: str
    cartons_produced: float = Field(ge=0)


class ProductionLineOut(BaseModel):
    id: uuid.UUID
    product_code: str
    product_name_ar: str
    product_name_en: str
    bottles_per_carton: int
    bottle_volume_ml: int
    cartons_produced: float


class ShiftDetail(ShiftBase):
    blow: Optional[BlowReportIn] = None
    filling: Optional[FillingReportIn] = None
    label: Optional[LabelReportIn] = None
    shrink: Optional[ShrinkReportIn] = None
    diesel: Optional[DieselReportIn] = None
    computed: Dict[str, Any] = {}
    inventory_posted: bool = False
    production_lines: List[ProductionLineOut] = []


class WarehouseOut(BaseModel):
    id: uuid.UUID
    code: str
    type: str
    name_ar: str
    name_en: str
    is_active: bool


class InventoryItemOut(BaseModel):
    id: uuid.UUID
    code: str
    item_type: str
    name_ar: str
    name_en: str
    uom: str
    is_active: bool


class InventoryTxnCreate(BaseModel):
    warehouse_code: str
    item_code: str
    txn_type: str = Field(pattern="^(RECEIVE|ISSUE|ADJUST)$")
    qty: float
    txn_date: date
    note: Optional[str] = None


class InventoryTxnOut(BaseModel):
    id: uuid.UUID
    warehouse_code: str
    warehouse_name_ar: str
    warehouse_name_en: str
    item_code: str
    item_name_ar: str
    item_name_en: str
    txn_type: str
    qty: float
    txn_date: date
    reference_type: Optional[str] = None
    reference_id: Optional[str] = None
    note: Optional[str] = None
    created_at: datetime


class StockRow(BaseModel):
    warehouse_code: str
    warehouse_name_ar: str
    warehouse_name_en: str
    item_code: str
    item_name_ar: str
    item_name_en: str
    uom: str
    qty_on_hand: float


class TransferLineCreate(BaseModel):
    item_code: str
    qty: float = Field(gt=0)


class StockTransferCreate(BaseModel):
    from_warehouse_code: str
    to_warehouse_code: str
    lines: List[TransferLineCreate] = Field(min_length=1)
    note: Optional[str] = None


class TransferLineOut(BaseModel):
    id: uuid.UUID
    item_code: str
    item_name_ar: str
    item_name_en: str
    uom: str
    qty: float


class StockTransferOut(BaseModel):
    id: uuid.UUID
    transfer_number: str
    from_warehouse_code: str
    from_warehouse_name_ar: str
    from_warehouse_name_en: str
    to_warehouse_code: str
    to_warehouse_name_ar: str
    to_warehouse_name_en: str
    status: str
    note: Optional[str] = None
    issued_by_username: str
    issued_by_full_name: Optional[str] = None
    issued_at: datetime
    responded_by_username: Optional[str] = None
    responded_by_full_name: Optional[str] = None
    responded_at: Optional[datetime] = None
    response_note: Optional[str] = None
    lines: List[TransferLineOut] = []


class TransferRespondRequest(BaseModel):
    action: str = Field(pattern="^(ACCEPTED|REJECTED)$")
    response_note: Optional[str] = None


class BOMLineOut(BaseModel):
    id: uuid.UUID
    item_code: str
    item_name_ar: str
    item_name_en: str
    uom: str
    qty_per_carton: float


class ProductOut(BaseModel):
    id: uuid.UUID
    code: str
    name_ar: str
    name_en: str
    bottle_volume_ml: int
    bottles_per_carton: int
    is_active: bool
    bom_lines: List[BOMLineOut] = []


class ConsumptionLineOut(BaseModel):
    item_code: str
    item_name_ar: str
    item_name_en: str
    uom: str
    total_required: float
    wh2_on_hand: float
    consumed_from_wh2: float
    missing_to_wh2_1: float


class ShiftConsumptionOut(BaseModel):
    shift_id: uuid.UUID
    production_lines: List[ProductionLineOut] = []
    consumption: List[ConsumptionLineOut] = []
    total_finished_cartons: Dict[str, float] = {}
